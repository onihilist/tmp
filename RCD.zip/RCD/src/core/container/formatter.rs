
use std::fs;
use std::io::Write;
use crate::core::container::{RCPortMapping, RCService};

fn generate_compose(services: Vec<RCService>) -> Result<(), std::io::Error> {
    let mut file = fs::File::create("docker-compose.yml")?;
    let mut writer = std::io::BufWriter::new(file);

    writer.write_all(b"version: '3'\n")?;
    writer.write_all(b"services:\n")?;

    for service in services {
        writer.write_all(format!("  {}:\n", service.name).as_bytes())?;
        writer.write_all(format!("    image: {}\n", service.image).as_bytes())?;
        writer.write_all(format!("    ports:\n").as_bytes())?;
        for port in service.ports {
            writer.write_all(format!("      - '{}:{}'\n", port.host, port.container).as_bytes())?;
        }
        writer.write_all(format!("    environment:\n").as_bytes())?;
        for (key, value) in service.env {
            writer.write_all(format!("      {}={}\n", key, value).as_bytes())?;
        }
        writer.write_all(b"\n")?;
    }

    Ok(())
}

fn main() {
    let services = vec![
        RCService {
            name: "web".to_string(),
            image: "nginx:latest".to_string(),
            ports: vec![
                RCPortMapping {
                    host: "8080".to_string(),
                    container: "80".to_string(),
                },
            ],
            env: vec![("FOO".to_string(), "bar".to_string())],
        },
        RCService {
            name: "db".to_string(),
            image: "postgres:latest".to_string(),
            ports: vec![],
            env: vec![("POSTGRES_PASSWORD".to_string(), "mysecretpassword".to_string())],
        },
    ];

    generate_compose(services).unwrap();
}