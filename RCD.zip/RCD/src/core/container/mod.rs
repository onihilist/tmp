
mod formatter;
mod networks;

use std::collections::HashMap;
use std::io::Write;
use networks::RCNetwork;

#[derive(Debug)]
pub struct RCServices {
    containers: [RCContainer]
}

#[derive(Debug)]
struct RCContainer {
    name: String,
    image: String,
    build: Option<String>,
    command: Option<String>,
    depends_on: Option<String>,
    environment: HashMap<String, String>,
    volumes: Vec<String>,
    ports: Vec<RCPortMapping>,
    networks: RCNetwork,
    restart_policy: Option<String>,
    healthcheck: Option<String>,
    deploy_policy: Option<String>,
    logging: Option<String>,
    labels: Option<HashMap<String, String>>,
    secrets: Option<HashMap<String, String>>,
    working_directory: Option<String>,
    network_mode: Option<String>,
    entrypoint: Option<String>,
}

#[derive(Debug)]
struct RCPortMapping {
    host: String,
    container: String,
}

impl RCContainer {

    fn new(name: &str, image: &str) -> Self {
        RCContainer {
            name: name.to_string(),
            image: image.to_string(),
            build: None,
            command: None,
            ports: Vec::new(),
            environment: HashMap::new(),
            volumes: Vec::new(),
            restart_policy: None,
            healthcheck: None,
            deploy_policy: None,
            logging: None,
            labels: None,
            secrets: None,
            working_directory: None,
            network_mode: None,
            depends_on: None,
            networks: RCNetwork,
            entrypoint: None,
        }
    }

    fn add_port(&mut self, host: &str, container: &str) {
        self.ports.push(RCPortMapping {
            host: host.to_string(),
            container: container.to_string(),
        });
    }

    fn add_environment(&mut self, key: &str, value: &str) {
        self.environment.insert(key.to_string(), value.to_string());
    }

    fn add_volume(&mut self, volume: &str) {
        self.volumes.push(volume.to_string());
    }
    
    fn set_restart_policy(&mut self, policy: &str) {
        self.restart_policy = Some(policy.to_string());
    }

}

fn main() {
    let mut web_container = RCContainer::new("web", "nginx:latest");
    web_container.add_port("8080", "80");
    web_container.add_environment("ENV_VAR", "value");
    web_container.add_volume("/host/path:/container/path");
    web_container.set_restart_policy("always");

    println!("{:?}", web_container);
}