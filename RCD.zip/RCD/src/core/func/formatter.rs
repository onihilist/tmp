
pub struct ContainerFunc<F, T> {
    pub name: String,
    pub func: F,
    pub returntype: T
}

